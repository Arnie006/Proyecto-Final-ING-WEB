-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: ingweb
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medicos`
--

DROP TABLE IF EXISTS `medicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombre_medico` varchar(50) NOT NULL,
  `id_especialidad` int NOT NULL,
  `id_complejo` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `id_especialidad` (`id_especialidad`),
  KEY `id_complejo` (`id_complejo`),
  CONSTRAINT `medicos_ibfk_1` FOREIGN KEY (`id_especialidad`) REFERENCES `especialidad` (`id`),
  CONSTRAINT `medicos_ibfk_2` FOREIGN KEY (`id_complejo`) REFERENCES `complejos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicos`
--

LOCK TABLES `medicos` WRITE;
/*!40000 ALTER TABLE `medicos` DISABLE KEYS */;
INSERT INTO `medicos` VALUES (1,'juan.barrios','juanb12345','Juan Barrios',1,1),(2,'luis.alberto','luisa12345','Luis Alberto',1,1),(3,'mauricio.gonzalez','mauriciog12345','Mauricio Gonzalez',2,1),(4,'gustavo.espinosa','gustavoe12345','Gustavo Espinosa',2,1),(5,'diego.montenegro','diegom12345','Diego Montenegro',3,1),(6,'alejandro.espino','alejandroe12345','Alejandro Espino',3,1),(7,'paolo.marine','paolom12345','Paolo Marine',4,1),(8,'rolando.chanis','rolandoc12345','Rolando Chanis',4,1),(9,'juan.alcedo','juana12345','Juan Alcedo',5,1),(10,'tomas.fraser','tomasf12345','Tomas Fraser',5,1),(11,'henry.chen','henryc12345','Henry Chen',1,2),(12,'maria.cabrera','mariac12345','Maria Cabrera',1,2),(13,'lucas.gonzalez','lucasg12345','Lucas Gonzalez',2,2),(14,'julian.diaz','juliand12345','Julian Diaz',2,2),(15,'kevin.williams','kevinw12345','Kevin Williams',3,2),(16,'carlos.wilson','carlosw12345','Carlos Wilson',3,2),(17,'alejandro.vives','alejandrov12345','Alejandro Vives',4,2),(18,'andres.carrizo','andresc12345','Andres Carrizo',4,2),(19,'josue.guerrero','josueg12345','Josue Guerrero',5,2),(20,'rodrigo.gonzalez','rodrigog12345','Rodrigo Gonzalez',5,2),(21,'juan.jacome','juanj12345','Juan Jacome',1,3),(22,'roberto.lambrano','robertol12345','Roberto Lambraño',2,3),(23,'eduardo.dominguez','eduardod12345','Eduardo Dominguez',2,3),(24,'eric.guevara','ericg12345','Eric Guevara',3,3),(25,'harmodio.cedeno','harmodioc12345','Harmodio Cedeño',3,3),(26,'alison.len','alisonl12345','Alison Len',4,3),(27,'mario.montenegro','mariom12345','Mario Montenegro',4,3),(28,'ricardo.rivera','ricardor12345','Ricardo Rivera',5,3),(29,'lacre.atura','lacrea12345','Lacre Atura',5,3),(30,'fernando.samudio','fernandos12345','Fernando Samudio',1,4),(31,'melanie.len','melaniel12345','Melanie Len',1,4),(32,'elianne.pauli','eliannep12345','Elianne Pauli',2,4),(33,'manuel.castillo','manuelc12345','Manuel Castillo',2,4),(34,'vivian.leon','vivianl12345','Vivian Leon',3,4),(35,'elmon.grel','elmong12345','Elmon Grel',3,4),(36,'cristobal.bolaños','cristobalb12345','Cristobal Bolaños',4,4),(37,'demetrio.jaramillo','demetrioj12345','Demetrio Jaramillo',4,4),(38,'jose.dutari','josed12345','Jose Dutari',5,4),(39,'daniel.marquez','danielm12345','Daniel Marquez',5,4),(40,'jean.alvarez','jeana12345','Jean Alvarez',1,5),(41,'gaspar.campos','gasparg12345','Gaspar Campos',1,5),(42,'rodrigo.moran','rodrigom12345','Rodrigo Moran',2,5),(43,'nathalie.ng','nathalien12345','Nathalie Ng',2,5),(44,'valentina.aizpurua','valentinaa12345','Valentina Aizpurua',3,5),(45,'daniella.cantres','daniellac12345','Daniella Cantres',3,5),(46,'alonso.plato','alonsop12345','Alonso Plato',4,5),(47,'andres.urieta','andresu12345','Andres Urieta',4,5),(48,'mike.chang','mikec12345','Mike Chang',5,5),(49,'fherney.pardo','fherneyp12345','Fherney Pardo',5,5),(50,'javier.torre','javiert12345','Javier Torre',1,3);
/*!40000 ALTER TABLE `medicos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-11  5:11:51
