<!DOCTYPE html>
<html>
<head>
<title>Contacto</title>
<link rel="stylesheet" href="pfestilos.css">
<link rel="icon" href="logo1.png">
</head>
<body>
<h1><img src="logo1.png" width="100" height="100" align="center" style="margin-right: 20px">SISTEMA ELECTRÓNICO DE CITAS</h1>
<a href="javascript:history.back()" style="bottom:0; left:0; right:0; text-align:left; font-size:12px">Regresar</a>
<h1 style="text-shadow: none">Sobre nosotros</h1>
<table align="center" style="text-align:center">
<tr>
<td><img src= "alexis.png" height="85" width="85"></td>
<td><img src= "arnulfo.png" height="85" width="85" style="margin-left:50px; margin-right:50px"></td>
<td><img src= "pedro.png" height="85" width="48"></td>
</tr>
<tr>
<td><p style="font-size:15px">Alexis<br>alexis.cortez1@utp.ac.pa</p></td>
<td><p style="font-size:15px; margin-left:50px; margin-right:50px">Arnulfo<br>arnulfo.sandoval@utp.ac.pa</p></td>
<td><p style="font-size:15px">Pedro<br>pedro.castillo3@utp.ac.pa</p></td>
</tr>
</table><br><br>
</body>
</html>